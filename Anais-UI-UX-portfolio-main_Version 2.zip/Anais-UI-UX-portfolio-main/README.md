Update 15/05/2024 ( statement )
I removed my project page because i want to focus on the aboutme and home page first ! 
I put the basis of my css just so i understand the exercise but i will take extra time after to make the website i am dreaming of ! 
So i will just finish the exercise and try everything so i learn without headaches !
